//
//  Governor.h
//  Governor
//
//  Created by Juan Luis Montero Roca on 3/10/17.
//  Copyright © 2017 Tiendeo Web Marketing. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Governor.
FOUNDATION_EXPORT double GovernorVersionNumber;

//! Project version string for Governor.
FOUNDATION_EXPORT const unsigned char GovernorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Governor/PublicHeader.h>


